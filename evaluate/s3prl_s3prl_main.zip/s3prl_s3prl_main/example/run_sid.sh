#!/bin/bash

python3 s3prl/main.py SuperbSID --target_dir result/tmp/ic --prepare_data.dataset_root /home/leo/d/datasets/VoxCeleb1/ --build_upstream.name apc

