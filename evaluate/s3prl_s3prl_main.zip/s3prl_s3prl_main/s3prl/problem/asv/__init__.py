"""
Speaker Verification recipes
"""

from .superb_asv import SuperbASV

__all__ = ["SuperbASV"]
